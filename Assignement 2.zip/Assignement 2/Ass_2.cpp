#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    // Menu items and prices
    const double BURGER_PRICE = 15.00;
    const double PIE_PRICE = 5.00;
    const double TURKEY_BACON_AVOCADO_PRICE = 15.00;
    const double DB_CLUBHOUSE_PRICE = 16.00;
    const double CHICKEN_QUESADILLA_PRICE = 11.50;
    const double CHICKEN_FRIES_PRICE = 11.00;

    const double ICE_CREAM_DESERT_PRICE = 3.00;
    const double COOKIES_DESERT_PRICE = 3.00;
    const double ONE_PANCAKE_DESERT_PRICE = 4.00;

    // Display welcome message and menu
    cout << setw(60) << setfill('*') << "Welcome to Discovery Bay Golf and Country Club Restaurant" << setw(20) << setfill('*') << "" << endl;
    
    // Display Meal Menu
    cout << left << setw(30) << "| Meal" << setw(20) << "| Price |" << endl;
    cout << setfill('-') << setw(50) << "" << setfill(' ') << endl;
    cout << left << setw(30) << "Discovery Bay Burger (B)" << setw(10) << "$" << BURGER_PRICE << endl;
    cout << left << setw(30) << "Turkey, Bacon & Avocado (T)" << setw(10) << "$" << TURKEY_BACON_AVOCADO_PRICE << endl;
    cout << left << setw(30) << "DB Clubhouse (C)" << setw(10) << "$" << DB_CLUBHOUSE_PRICE << endl;
    cout << left << setw(30) << "Chicken Quesadilla (Q)" << setw(10) << "$" << CHICKEN_QUESADILLA_PRICE << endl;
    cout << left << setw(30) << "Chicken Fries (F)" << setw(10) << "$" << CHICKEN_FRIES_PRICE << endl;

    // Display Dessert Menu
    cout << left << setw(30) << "| Dessert" << setw(20) << "| Price |" << endl;
    cout << setfill('-') << setw(50) << "" << setfill(' ') << endl;
    cout << left << setw(30) << "Pie (P)" << setw(10) << "$" << PIE_PRICE << endl;
    cout << left << setw(30) << "Ice Cream (I)" << setw(10) << "$" << ICE_CREAM_DESERT_PRICE << endl;
    cout << left << setw(30) << "Cookies (C)" << setw(10) << "$" << COOKIES_DESERT_PRICE << endl;
    cout << left << setw(30) << "One Pancake (O)" << setw(10) << "$" << ONE_PANCAKE_DESERT_PRICE << endl;

    // Get user input for meal and dessert
    char mealChoice, desertChoice;
    cout << "Enter a Meal that you would like to order: ";
    cin >> mealChoice;
    cout << "Enter a Dessert that you would like to order: ";
    cin >> desertChoice;

    // Calculate subtotal
    double subtotal = 0.0;
    switch (mealChoice) {
        case 'B':
            subtotal += BURGER_PRICE;
            break;
        case 'T':
            subtotal += TURKEY_BACON_AVOCADO_PRICE;
            break;
        case 'C':
            subtotal += DB_CLUBHOUSE_PRICE;
            break;
        case 'Q':
            subtotal += CHICKEN_QUESADILLA_PRICE;
            break;
        case 'F':
            subtotal += CHICKEN_FRIES_PRICE;
            break;
        default:
            cout << "Invalid Meal choice!" << endl;
            return 1; // Exit with an error code
    }

    switch (desertChoice) {
        case 'P':
            subtotal += PIE_PRICE;
            break;
        case 'I':
            subtotal += ICE_CREAM_DESERT_PRICE;
            break;
        case 'C':
            subtotal += COOKIES_DESERT_PRICE;
            break;
        case 'O':
            subtotal += ONE_PANCAKE_DESERT_PRICE;
            break;
        default:
            cout << "Invalid Dessert choice!" << endl;
            return 1; // Exit with an error code
    }

    // Calculate sales tax (assuming 8% sales tax)
    double salesTaxRate = 0.08;
    double salesTax = subtotal * salesTaxRate;

    // Calculate total
    double total = subtotal + salesTax;

    // Display results
    cout << fixed << setprecision(2);
    cout << "Sales Tax: $" << setw(10) << salesTax << showpoint << endl;
    cout << "Your total is $" << setw(10) << total << " and this will go to member charge!" << endl;
    cout << "Thank you for dining with us at Discovery Bay Golf and Country Club! You made Matt Padilla happy :)" << endl;

    return 0;
}
