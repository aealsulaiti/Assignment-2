# Enhanced Discovery Bay Golf and Country Club Restaurant

## Overview

Welcome back to the improved version of the Discovery Bay Golf and Country Club Restaurant! In this updated C++ console application, we've incorporated various shortcuts and manipulators to enhance the user experience. The program now leverages the following shortcuts discussed in Lecture 4:

- `setprecision()`
- `showpoint`
- `setw()`
- `setfill()`
- `left`/`right` manipulators

## Shortcuts and Manipulators Usage

### 1. `setprecision()` and `showpoint`

We've used `setprecision()` to control the number of decimal places displayed and `showpoint` to ensure that trailing zeros are shown for floating-point values.

### 2. `setw()` and `setfill()`

`setw()` is employed to set the field width for displaying values, providing a neat and organized appearance. `setfill()` ensures that the specified character fills the empty space within the set width.

### 3. `left`/`right` Manipulators

The `left` and `right` manipulators are used to align text to the left or right within the specified width, improving the overall readability of the output.

## How to Use

1. **Clone the Repository:**

2. **Compile and Run:**

   - Compile the enhanced C++ code using a C++ compiler (e.g., g++).
   - Run the compiled executable.

3. **Place Your Order:**

   - Enter the meal choice (B, T, C, Q, F) when prompted.
   - Enter the dessert choice (P, I, C, O) when prompted.

4. **View Results:**

   - The application will calculate the subtotal, apply sales tax, and display the total amount billed to the member charge. The output is now formatted using the shortcuts and manipulators for improved clarity.

5. **Thank You:**

   - Thank you for dining with us at Discovery Bay Golf and Country Club! We hope you appreciate the enhanced presentation and find the dining experience even more enjoyable.

6. ## OUTPUT:

![e5e7331c-0071-47bf-b4a9-89f891975815](C:\Users\pc\Downloads\e5e7331c-0071-47bf-b4a9-89f891975815.jpeg)